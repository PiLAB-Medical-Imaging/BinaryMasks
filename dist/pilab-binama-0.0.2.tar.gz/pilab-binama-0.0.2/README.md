# Binary Masks Operations

Welcome to the Binary Masks Operations's Github repository! 

## Description

This package contains helpful functions enabling a faster clean up of binary masks and other functionalities.